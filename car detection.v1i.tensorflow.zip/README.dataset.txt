# car detection > 2023-07-10 8:56pm
https://universe.roboflow.com/car-detection-dcnsx/car-detection-xkan2

Provided by a Roboflow user
License: CC BY 4.0

